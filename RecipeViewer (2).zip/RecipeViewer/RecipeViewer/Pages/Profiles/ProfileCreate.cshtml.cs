using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RecipeViewer.Models;

namespace RecipeViewer.Pages.Profiles
{
    [BindProperties]
    public class IndexModel : PageModel
    {
        public Profile ProfileRecord { get; set; }
        public List<string> PRole { get; set; } = new List<string> { "User"};
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RecipeViewer;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"INSERT INTO Profile(first_name, username, password, role) VALUES (@PName, @PUser, @PPW, @PRole)";

                command.Parameters.AddWithValue("@PName", ProfileRecord.first_name);
                command.Parameters.AddWithValue("@PUser", ProfileRecord.username);
                command.Parameters.AddWithValue("@PPW", ProfileRecord.password);
                command.Parameters.AddWithValue("@PRole", ProfileRecord.role);

                Console.WriteLine(ProfileRecord.first_name);
                Console.WriteLine(ProfileRecord.username);
                Console.WriteLine(ProfileRecord.password);
                Console.WriteLine(ProfileRecord.role);

                command.ExecuteNonQuery();

            }

            return RedirectToPage("/Login/Login");
        }
    }
}
