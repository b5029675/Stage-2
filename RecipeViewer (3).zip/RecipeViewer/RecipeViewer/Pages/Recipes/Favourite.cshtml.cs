using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using RecipeViewer.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;

namespace RecipeViewer.Pages.Recipes
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public Profile ProfileFav { get; set; }

        public IActionResult OnGet(int? id)
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RecipeViewer;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";


            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            ProfileFav = new Profile();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM Profile WHERE Id = @RID";

                command.Parameters.AddWithValue("@RID", id);
                Console.WriteLine("The id : " + id);

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ProfileFav.Id = reader.GetInt32(0);
                    ProfileFav.first_name = reader.GetString(1);
                    ProfileFav.username = reader.GetString(2);
                    ProfileFav.password = reader.GetString(3);
                    ProfileFav.role = reader.GetString(4);
                }

                command.Connection = conn;
                command.CommandText = @"INSERT INTO Profile (favourites) VALUES (@fav)";

                command.Parameters.Add("@Pfav" + "");
            }

            return RedirectToPage("/UserPages/UserIndex");
        }
    }
}
        