using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RecipeViewer.Models;
using RecipeViewer.Pages.DatabaseConnection;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Http;

namespace RecipeViewer.Pages.Login
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public Profile Profile { get; set; }

        public string Message { get; set; }

        public string SessionID;

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page(); 
            }

            DatabaseConnect dbstring = new DatabaseConnect(); //creating an object from the class
            string DbConnection = dbstring.DatabaseString(); //calling the method from the class
            Console.WriteLine(DbConnection);
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine(Profile.username);
            Console.WriteLine(Profile.password);

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT first_name, username, role FROM Profile WHERE username = @PUser AND password = @PPW";

                command.Parameters.AddWithValue("@PUser", Profile.username);
                command.Parameters.AddWithValue("@PPW", Profile.password);

                var reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Profile.first_name = reader.GetString(0);
                    Profile.username = reader.GetString(1);
                    Profile.role = reader.GetString(2);
                }
            }

            if (!string.IsNullOrEmpty(Profile.first_name))
            {
                SessionID = HttpContext.Session.Id;
                HttpContext.Session.SetString("sessionID", SessionID);
                HttpContext.Session.SetString("username", Profile.username);
                HttpContext.Session.SetString("fname", Profile.first_name);

                if (Profile.role == "User")
                {
                    return RedirectToPage("/UserPages/UserIndex");
                }
                else
                {
                    return RedirectToPage("/AdminPages/AdminIndex");
                }


            }
            else
            {
                Message = "Invalid Username and Password!";
                return Page();
            }

        }
        public void OnGet()
        {
        }
    }
}
