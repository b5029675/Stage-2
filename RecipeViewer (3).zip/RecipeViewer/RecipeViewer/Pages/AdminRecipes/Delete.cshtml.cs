using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RecipeViewer.Models;

namespace RecipeViewer.Pages.AdminRecipes
{
    public class DeleteModel : PageModel
    {
        [BindProperty]
        public Recipe RecipeRec { get; set; }
        public IActionResult OnGet(int? id)
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RecipeViewer;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM Recipe WHERE Id = @RID";
                command.Parameters.AddWithValue("@RID", id);

                SqlDataReader reader = command.ExecuteReader();
                RecipeRec = new Recipe();
                while (reader.Read())
                {
                    RecipeRec.Id = reader.GetInt32(0);
                    RecipeRec.name = reader.GetString(1);
                    RecipeRec.calories = reader.GetInt32(2);
                    RecipeRec.time = reader.GetString(3);
                    RecipeRec.category = reader.GetString(4);
                    RecipeRec.difficulty = reader.GetString(5);
                    RecipeRec.serving = reader.GetInt32(6);
                }

            }

            conn.Close();

            return Page();

        }
        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RecipeViewer;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "DELETE FROM Recipe WHERE Id = @RID";
                command.Parameters.AddWithValue("@RID", RecipeRec.Id);
                command.ExecuteNonQuery();
            }

            conn.Close();
            return RedirectToPage("/AdminRecipes/View");

        }
    }
}

