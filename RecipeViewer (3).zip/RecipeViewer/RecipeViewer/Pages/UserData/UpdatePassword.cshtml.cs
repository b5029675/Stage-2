using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RecipeViewer.Models;

namespace RecipeViewer.Pages.UserData
{
    public class UpdatePasswordModel : PageModel
    {
        [BindProperty]
        public Profile PasswordUpdate { get; set; }

        public IActionResult OnGet(int? id)
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RecipeViewer;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();


            PasswordUpdate = new Profile();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM Profile WHERE Id = @RID";

                command.Parameters.AddWithValue("@RID", id);
                Console.WriteLine("The id : " + id);

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    PasswordUpdate.Id = reader.GetInt32(0);
                    PasswordUpdate.first_name = reader.GetString(1);
                    PasswordUpdate.username = reader.GetString(2);
                    PasswordUpdate.password = reader.GetString(3);
                    PasswordUpdate.role = reader.GetString(4);
                }


            }

            conn.Close();

            return Page();

        }

        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RecipeViewer;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();


            Console.WriteLine("Student Password : " + PasswordUpdate.password);


            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "UPDATE Profile SET password = @Ppass WHERE Id = @RID";

                command.Parameters.AddWithValue("@RID", PasswordUpdate.Id);
                command.Parameters.AddWithValue("@Ppass", PasswordUpdate.password);


                command.ExecuteNonQuery();
            }

            conn.Close();

            return RedirectToPage("/UserData/ViewUser");
        }

    }
}
