using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RecipeViewer.Models;

namespace RecipeViewer.Pages.RecipePages
{
    public class BeefburgerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
