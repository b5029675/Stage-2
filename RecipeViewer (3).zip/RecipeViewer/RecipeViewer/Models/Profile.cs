﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeViewer.Models
{
    public class Profile
    {
        public int Id { get; set; }
        [Display(Name ="Name")]
        public string first_name { get; set; }
        [Display(Name = "Username")]
        public string username { get; set; }
        [Display(Name = "Password")]
        public string password { get; set; }
        [Display(Name = "Role")]
        public string role { get; set; }
        [Display(Name = "Favourites")]
        public string favourites { get; set; }
    }
}
