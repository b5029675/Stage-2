﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeViewer.Models
{
    public class Recipe
    {
        public int Id { get; set; }
        [Display(Name="Recipe Name")]
        public string name { get; set; }
        [Display(Name ="Calories")]
        public int calories { get; set; }
        [Display(Name ="Time to make")]
        public string time { get; set; }
        [Display(Name ="Category")]
        public string category { get; set; }
        [Display(Name ="Difficulty")]
        public string difficulty { get; set; }
        [Display(Name ="Serves")]
        public int serving { get; set; }
    }
}
