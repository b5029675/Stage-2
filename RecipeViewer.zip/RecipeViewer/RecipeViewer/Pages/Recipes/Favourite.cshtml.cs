using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using RecipeViewer.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RecipeViewer.Pages.Recipes
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public Recipe RecipeRec { get; set; }
        public void OnGet()
        {
        }


    }
}
