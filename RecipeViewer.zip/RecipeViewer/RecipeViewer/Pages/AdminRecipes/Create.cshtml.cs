using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using RecipeViewer.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RecipeViewer.Pages.AdminRecipes
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public Recipe RecipeRec { get; set; }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RecipeViewer;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"INSERT INTO Profile (name, calories, time, category, difficulty, serving) VALUES (@Rname, @Rcalories, @Rtime, @Rcategory, @Rdifficulty, @Rserving)";

                command.Parameters.AddWithValue("@Rname", RecipeRec.name);
                command.Parameters.AddWithValue("@Rcalories", RecipeRec.calories);
                command.Parameters.AddWithValue("@Rtime", RecipeRec.time);
                command.Parameters.AddWithValue("@Rcategory", RecipeRec.category);
                command.Parameters.AddWithValue("@Rdifficulty", RecipeRec.difficulty);
                command.Parameters.AddWithValue("@Rserving", RecipeRec.serving);


                Console.WriteLine(RecipeRec.name);
                Console.WriteLine(RecipeRec.calories);
                Console.WriteLine(RecipeRec.time);
                Console.WriteLine(RecipeRec.category);
                Console.WriteLine(RecipeRec.difficulty);
                Console.WriteLine(RecipeRec.serving);



                command.ExecuteNonQuery();
            }



            return RedirectToPage("/Index");
        }
    }
}
