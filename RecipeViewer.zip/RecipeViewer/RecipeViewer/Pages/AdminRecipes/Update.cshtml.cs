using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RecipeViewer.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace RecipeViewer.Pages.AdminRecipes
{
    public class UpdateModel : PageModel
    {
        [BindProperty]
        public Recipe RecipeRec { get; set; }

        public IActionResult OnGet(int? id)
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RecipeViewer;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();


            RecipeRec = new Recipe();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM Recipe WHERE Id = @RID";

                command.Parameters.AddWithValue("@RID", id);
                Console.WriteLine("The id : " +id);

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    RecipeRec.Id = reader.GetInt32(0);
                    RecipeRec.name = reader.GetString(1);
                    RecipeRec.calories = reader.GetInt32(2);
                    RecipeRec.time = reader.GetString(3);
                    RecipeRec.category = reader.GetString(4);
                    RecipeRec.difficulty = reader.GetString(5);
                    RecipeRec.serving = reader.GetInt32(6);
                }


            }

            conn.Close();

            return Page();

        }

        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=RecipeViewer;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine("Recipe ID : " + RecipeRec.Id);
            Console.WriteLine("Recipe Name : " + RecipeRec.name);
            Console.WriteLine("Recipe Calories : " + RecipeRec.calories);
            Console.WriteLine("Student Time to make : " + RecipeRec.time);
            Console.WriteLine("Student Category : " + RecipeRec.category);
            Console.WriteLine("Student Difficulty : " + RecipeRec.difficulty);
            Console.WriteLine("Student Serving Suggestion : " + RecipeRec.serving);

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "UPDATE Recipe SET name = @Rname, calories = @Rcalories, time = @Rtime, category = @Rcategory, difficulty = @Rdifficulty, serving = @Rserving WHERE Id = @RID";

                command.Parameters.AddWithValue("@RID", RecipeRec.Id);
                command.Parameters.AddWithValue("@Rname", RecipeRec.name);
                command.Parameters.AddWithValue("@Rcalories", RecipeRec.calories);
                command.Parameters.AddWithValue("@Rtime", RecipeRec.time);
                command.Parameters.AddWithValue("@Rcategory", RecipeRec.category);
                command.Parameters.AddWithValue("@Rdifficulty", RecipeRec.difficulty);
                command.Parameters.AddWithValue("@Rserving", RecipeRec.serving);

                command.ExecuteNonQuery();
            }

            conn.Close();

            return RedirectToPage("/AdminRecipes/View");
        }

    }
}
