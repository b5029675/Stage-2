﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeViewer.Models
{
    public class Profile
    {
        public int Id { get; set; }
        public string first_name { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        [Display(Name = "Role")]
        public string role { get; set; }

        public string favourites { get; set; }
    }
}
